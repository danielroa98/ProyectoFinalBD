# ProyectoFinalBD
Proyecto final para la clase Base de Datos, tienda virtual de juegos "indies", de estudios relativamente pequeños e independientes.

Codificado por Daniel Roa, Luis Ortiz y Sebastian Vives.
